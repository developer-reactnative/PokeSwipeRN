/**
 * PokemonContext - Global State Management
 * 
 * Provides global state for the entire PokeSwipe application using React Context.
 * Handles persistence of data using AsyncStorage.
 * 
 * STATE MANAGED:
 * - likedPokemon: Array of Pokemon the user has liked
 * - isDarkMode: Boolean for dark/light theme preference
 * - seenPokemonIds: Array of Pokemon IDs user has already seen (to avoid duplicates)
 * 
 * PERSISTENCE:
 * All state is automatically saved to AsyncStorage and restored on app launch.
 * 
 * USAGE:
 * Wrap your app with <PokemonProvider> and use usePokemon() hook to access state.
 * 
 * @example
 * const { likedPokemon, addLikedPokemon, isDarkMode, toggleDarkMode } = usePokemon();
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LikedPokemon } from '../types/pokemon';

/**
 * Context type definition
 * Defines all values and functions available through the context
 */
interface PokemonContextType {
  // Liked Pokemon Management
  likedPokemon: LikedPokemon[];               // Array of liked Pokemon
  addLikedPokemon: (pokemon: LikedPokemon) => void;  // Add a Pokemon to liked
  removeLikedPokemon: (id: number) => void;   // Remove a Pokemon from liked
  isLiked: (id: number) => boolean;           // Check if Pokemon is already liked
  
  // Theme Management
  isDarkMode: boolean;                         // Current theme state
  toggleDarkMode: () => void;                  // Toggle between light/dark
  
  // Seen Pokemon Tracking (to avoid showing duplicates)
  seenPokemonIds: number[];                    // IDs of Pokemon user has seen
  addSeenPokemon: (id: number) => void;        // Mark a Pokemon as seen
  clearSeenPokemon: () => void;                // Reset seen Pokemon list
}

// Create the context with undefined default (will be provided by PokemonProvider)
const PokemonContext = createContext<PokemonContextType | undefined>(undefined);

/**
 * AsyncStorage keys for persisted data
 * Using a namespace prefix to avoid conflicts with other apps
 */
const STORAGE_KEYS = {
  LIKED_POKEMON: '@PokeSwipe:likedPokemon',    // Liked Pokemon array
  DARK_MODE: '@PokeSwipe:darkMode',            // Theme preference
  SEEN_POKEMON: '@PokeSwipe:seenPokemon',      // Seen Pokemon IDs
};

// Provider component props
interface PokemonProviderProps {
  children: ReactNode;
}

/**
 * PokemonProvider Component
 * 
 * Wraps the application and provides global state to all child components.
 * Handles loading saved data on mount and persisting changes.
 * 
 * @param children - Child components that will have access to the context
 */
export const PokemonProvider: React.FC<PokemonProviderProps> = ({ children }) => {
  // ==================== STATE ====================
  
  // Array of Pokemon the user has liked
  const [likedPokemon, setLikedPokemon] = useState<LikedPokemon[]>([]);
  
  // Dark mode preference
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // IDs of Pokemon user has already seen (to avoid showing duplicates)
  const [seenPokemonIds, setSeenPokemonIds] = useState<number[]>([]);

  // ==================== DATA PERSISTENCE ====================

  /**
   * Load saved data from AsyncStorage on component mount
   * Restores liked Pokemon, dark mode preference, and seen Pokemon
   */
  useEffect(() => {
    loadSavedData();
  }, []);

  /**
   * Loads all persisted data from AsyncStorage
   * Uses Promise.all for parallel loading efficiency
   */
  const loadSavedData = async () => {
    try {
      // Load all data in parallel
      const [likedData, darkModeData, seenData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.LIKED_POKEMON),
        AsyncStorage.getItem(STORAGE_KEYS.DARK_MODE),
        AsyncStorage.getItem(STORAGE_KEYS.SEEN_POKEMON),
      ]);

      // Parse and set liked Pokemon if exists
      if (likedData) {
        setLikedPokemon(JSON.parse(likedData));
      }
      
      // Parse and set dark mode preference if exists
      if (darkModeData) {
        setIsDarkMode(JSON.parse(darkModeData));
      }
      
      // Parse and set seen Pokemon IDs if exists
      if (seenData) {
        setSeenPokemonIds(JSON.parse(seenData));
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  };

  // ==================== LIKED POKEMON MANAGEMENT ====================

  /**
   * Adds a Pokemon to the liked collection
   * Persists the updated array to AsyncStorage
   * 
   * @param pokemon - LikedPokemon object to add
   */
  const addLikedPokemon = async (pokemon: LikedPokemon) => {
    const updated = [...likedPokemon, pokemon];
    setLikedPokemon(updated);
    
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.LIKED_POKEMON, JSON.stringify(updated));
    } catch (error) {
      console.error('Error saving liked Pokemon:', error);
    }
  };

  /**
   * Removes a Pokemon from the liked collection by ID
   * Persists the updated array to AsyncStorage
   * 
   * @param id - Pokemon ID to remove
   */
  const removeLikedPokemon = async (id: number) => {
    const updated = likedPokemon.filter(p => p.id !== id);
    setLikedPokemon(updated);
    
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.LIKED_POKEMON, JSON.stringify(updated));
    } catch (error) {
      console.error('Error removing liked Pokemon:', error);
    }
  };

  /**
   * Checks if a Pokemon is already in the liked collection
   * 
   * @param id - Pokemon ID to check
   * @returns boolean - true if Pokemon is liked
   */
  const isLiked = (id: number): boolean => {
    return likedPokemon.some(p => p.id === id);
  };

  // ==================== THEME MANAGEMENT ====================

  /**
   * Toggles between dark and light mode
   * Persists the preference to AsyncStorage
   */
  const toggleDarkMode = async () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.DARK_MODE, JSON.stringify(newMode));
    } catch (error) {
      console.error('Error saving dark mode:', error);
    }
  };

  // ==================== SEEN POKEMON TRACKING ====================

  /**
   * Marks a Pokemon as seen (to avoid showing duplicates)
   * Persists the updated array to AsyncStorage
   * 
   * @param id - Pokemon ID that was seen
   */
  const addSeenPokemon = async (id: number) => {
    // Only add if not already in the list
    if (!seenPokemonIds.includes(id)) {
      const updated = [...seenPokemonIds, id];
      setSeenPokemonIds(updated);
      
      try {
        await AsyncStorage.setItem(STORAGE_KEYS.SEEN_POKEMON, JSON.stringify(updated));
      } catch (error) {
        console.error('Error saving seen Pokemon:', error);
      }
    }
  };

  /**
   * Clears all seen Pokemon IDs
   * Useful for resetting the app or allowing Pokemon to appear again
   */
  const clearSeenPokemon = async () => {
    setSeenPokemonIds([]);
    
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.SEEN_POKEMON);
    } catch (error) {
      console.error('Error clearing seen Pokemon:', error);
    }
  };

  // ==================== CONTEXT PROVIDER ====================

  return (
    <PokemonContext.Provider
      value={{
        // Liked Pokemon
        likedPokemon,
        addLikedPokemon,
        removeLikedPokemon,
        isLiked,
        
        // Theme
        isDarkMode,
        toggleDarkMode,
        
        // Seen Pokemon
        seenPokemonIds,
        addSeenPokemon,
        clearSeenPokemon,
      }}
    >
      {children}
    </PokemonContext.Provider>
  );
};

/**
 * usePokemon Hook
 * 
 * Custom hook to access the Pokemon context.
 * Must be used within a PokemonProvider.
 * 
 * @returns PokemonContextType - All context values and functions
 * @throws Error if used outside of PokemonProvider
 * 
 * @example
 * const { likedPokemon, addLikedPokemon } = usePokemon();
 */
export const usePokemon = (): PokemonContextType => {
  const context = useContext(PokemonContext);
  
  if (!context) {
    throw new Error('usePokemon must be used within a PokemonProvider');
  }
  
  return context;
};
