// Theme definitions for light and dark mode

export const lightTheme = {
  background: '#F5F5F5',
  card: '#FFFFFF',
  cardBorder: '#E0E0E0',
  text: '#333333',
  textSecondary: '#666666',
  primary: '#4CAF50',
  primaryDark: '#388E3C',
  danger: '#FF6B6B',
  dangerDark: '#D32F2F',
  accent: '#FF6B9D',
  headerBackground: '#FFFFFF',
  shadow: '#000000',
};

export const darkTheme = {
  background: '#1A1A2E',
  card: '#16213E',
  cardBorder: '#0F3460',
  text: '#EAEAEA',
  textSecondary: '#B0B0B0',
  primary: '#4CAF50',
  primaryDark: '#388E3C',
  danger: '#FF6B6B',
  dangerDark: '#D32F2F',
  accent: '#FF6B9D',
  headerBackground: '#16213E',
  shadow: '#000000',
};

export type Theme = typeof lightTheme;

