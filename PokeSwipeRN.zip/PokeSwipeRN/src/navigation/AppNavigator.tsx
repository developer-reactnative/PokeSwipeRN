// AppNavigator - Main navigation stack for the PokeSwipe app

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import WelcomeScreen from '../screens/WelcomeScreen';
import SwipeScreen from '../screens/SwipeScreen';
import LikedScreen from '../screens/LikedScreen';

// Define the navigation param list types
export type RootStackParamList = {
  Welcome: undefined;
  Swipe: undefined;
  Liked: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Welcome"
        screenOptions={{
          headerShown: false, // We use custom headers
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="Swipe" component={SwipeScreen} />
        <Stack.Screen name="Liked" component={LikedScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;

