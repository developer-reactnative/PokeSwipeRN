/**
 * PokeAPI Service
 * 
 * Handles all interactions with the PokeAPI (https://pokeapi.co/).
 * Provides functions to fetch Pokemon data and format it for display.
 * 
 * API ENDPOINTS USED:
 * - GET /api/v2/pokemon/{id} - Fetches a Pokemon by ID
 * 
 * IMAGE SOURCES:
 * - Official Artwork: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/{id}.png
 * - Dream World SVG: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/{id}.svg
 */

import { Pokemon } from '../types/pokemon';

/**
 * Base URL for PokeAPI
 */
const BASE_URL = 'https://pokeapi.co/api/v2';

/**
 * Maximum Pokemon ID to fetch from
 * Currently set to Gen 1-8 Pokemon (898 total)
 * Can be increased as new generations are added to PokeAPI
 */
const MAX_POKEMON_ID = 898;

/**
 * Generates a random Pokemon ID between 1 and MAX_POKEMON_ID
 * Used to fetch random Pokemon for the swipe feature
 * 
 * @returns number - Random Pokemon ID (1 to 898)
 */
export const getRandomPokemonId = (): number => {
  return Math.floor(Math.random() * MAX_POKEMON_ID) + 1;
};

/**
 * Fetches a Pokemon by ID from the PokeAPI
 * 
 * @param id - Pokemon ID to fetch (1-898)
 * @returns Promise<Pokemon> - Pokemon data object
 * @throws Error if API call fails or Pokemon not found
 * 
 * @example
 * const pikachu = await fetchPokemonById(25);
 * console.log(pikachu.name); // "pikachu"
 */
export const fetchPokemonById = async (id: number): Promise<Pokemon> => {
  const response = await fetch(`${BASE_URL}/pokemon/${id}`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch Pokemon with ID ${id}`);
  }
  
  return response.json();
};

/**
 * Fetches a random Pokemon from the PokeAPI
 * Combines getRandomPokemonId and fetchPokemonById for convenience
 * 
 * @returns Promise<Pokemon> - Random Pokemon data object
 * @throws Error if API call fails
 * 
 * @example
 * const randomPokemon = await fetchRandomPokemon();
 * console.log(randomPokemon.name); // Random Pokemon name
 */
export const fetchRandomPokemon = async (): Promise<Pokemon> => {
  const randomId = getRandomPokemonId();
  return fetchPokemonById(randomId);
};

/**
 * Gets the Dream World SVG sprite URL for a Pokemon
 * Dream World sprites are high-quality SVG images
 * 
 * Note: Not all Pokemon have Dream World sprites available
 * 
 * @param id - Pokemon ID
 * @returns string - URL to Dream World SVG sprite
 * 
 * @example
 * const url = getDreamWorldSpriteUrl(25);
 * // Returns: "https://raw.githubusercontent.com/.../dream-world/25.svg"
 */
export const getDreamWorldSpriteUrl = (id: number): string => {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/${id}.svg`;
};

/**
 * Gets the Official Artwork PNG sprite URL for a Pokemon
 * Official artwork is higher quality than standard sprites
 * This is the primary image source used in the app
 * 
 * @param id - Pokemon ID
 * @returns string - URL to Official Artwork PNG
 * 
 * @example
 * const url = getOfficialArtworkUrl(25);
 * // Returns: "https://raw.githubusercontent.com/.../official-artwork/25.png"
 */
export const getOfficialArtworkUrl = (id: number): string => {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
};

/**
 * Formats a Pokemon name for display
 * - Capitalizes first letter
 * - Replaces hyphens with spaces (for names like "mr-mime" -> "Mr mime")
 * 
 * @param name - Raw Pokemon name from API (lowercase with hyphens)
 * @returns string - Formatted name for display
 * 
 * @example
 * formatPokemonName("pikachu") // "Pikachu"
 * formatPokemonName("mr-mime") // "Mr mime"
 */
export const formatPokemonName = (name: string): string => {
  return name.charAt(0).toUpperCase() + name.slice(1).replace(/-/g, ' ');
};

/**
 * Formats an ability name for display
 * - Capitalizes first letter of each word
 * - Replaces hyphens with spaces
 * 
 * @param name - Raw ability name from API (lowercase with hyphens)
 * @returns string - Formatted ability name for display
 * 
 * @example
 * formatAbilityName("static") // "Static"
 * formatAbilityName("battle-armor") // "Battle Armor"
 */
export const formatAbilityName = (name: string): string => {
  return name
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};
