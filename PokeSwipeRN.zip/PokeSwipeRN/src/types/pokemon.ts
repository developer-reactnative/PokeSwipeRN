/**
 * Pokemon Type Definitions
 * 
 * TypeScript interfaces for Pokemon data structures used throughout the app.
 * Based on the PokeAPI response format (https://pokeapi.co/docs/v2#pokemon).
 * 
 * INTERFACES:
 * - PokemonType: Type information (fire, water, etc.)
 * - PokemonAbility: Ability information
 * - Pokemon: Full Pokemon data from API
 * - LikedPokemon: Simplified Pokemon data for local storage
 */

/**
 * Pokemon Type Interface
 * Represents a single type entry in the Pokemon's types array
 * 
 * @property slot - Position of this type (1 = primary, 2 = secondary)
 * @property type - Type details including name and API URL
 * 
 * @example
 * // Charizard's primary type
 * { slot: 1, type: { name: "fire", url: "https://pokeapi.co/api/v2/type/10/" } }
 */
export interface PokemonType {
  slot: number;
  type: {
    name: string;  // e.g., "fire", "water", "grass"
    url: string;   // API URL for detailed type info
  };
}

/**
 * Pokemon Ability Interface
 * Represents a single ability entry in the Pokemon's abilities array
 * 
 * @property ability - Ability details including name and API URL
 * @property is_hidden - Whether this is a hidden ability
 * @property slot - Ability slot position
 * 
 * @example
 * // Pikachu's Static ability
 * { ability: { name: "static", url: "..." }, is_hidden: false, slot: 1 }
 */
export interface PokemonAbility {
  ability: {
    name: string;  // e.g., "static", "blaze", "torrent"
    url: string;   // API URL for detailed ability info
  };
  is_hidden: boolean;  // Hidden abilities are harder to obtain in games
  slot: number;
}

/**
 * Pokemon Interface
 * Full Pokemon data structure as returned by the PokeAPI
 * Only includes fields used in this application
 * 
 * @property id - National Pokedex number (1-898+)
 * @property name - Pokemon name (lowercase, e.g., "pikachu")
 * @property types - Array of type information
 * @property abilities - Array of ability information
 * @property sprites - Image URLs for various sprite formats
 * @property height - Height in decimeters
 * @property weight - Weight in hectograms
 * 
 * @see https://pokeapi.co/docs/v2#pokemon
 */
export interface Pokemon {
  id: number;
  name: string;
  types: PokemonType[];
  abilities: PokemonAbility[];
  sprites: {
    front_default: string;  // Standard front-facing sprite
    other: {
      'official-artwork': {
        front_default: string;  // High-quality official artwork
      };
      dream_world: {
        front_default: string;  // Dream World SVG sprite
      };
    };
  };
  height: number;  // Height in decimeters (divide by 10 for meters)
  weight: number;  // Weight in hectograms (divide by 10 for kg)
}

/**
 * Liked Pokemon Interface
 * Simplified Pokemon data structure for local storage
 * Contains only the essential data needed to display in the collection
 * 
 * This is stored in AsyncStorage rather than the full Pokemon object
 * to reduce storage space and improve performance
 * 
 * @property id - National Pokedex number
 * @property name - Pokemon name (lowercase)
 * @property imageUrl - URL to official artwork image
 * @property types - Array of type names (e.g., ["fire", "flying"])
 * 
 * @example
 * {
 *   id: 6,
 *   name: "charizard",
 *   imageUrl: "https://.../official-artwork/6.png",
 *   types: ["fire", "flying"]
 * }
 */
export interface LikedPokemon {
  id: number;
  name: string;
  imageUrl: string;
  types: string[];
}
