/**
 * Pokemon Type Colors
 * 
 * Provides color mappings for all 18 Pokemon types.
 * Used throughout the app for visual styling based on Pokemon type.
 * 
 * USAGE:
 * - Card accent colors
 * - Type badges
 * - Heart icon colors
 * - ID badge backgrounds
 * 
 * COLOR PALETTE:
 * Each type has a standard color that matches the official Pokemon games.
 * Both regular and dark variants are provided for flexibility.
 */

/**
 * Standard type colors (lighter shades)
 * Used for backgrounds, accents, and highlights
 */
export const typeColors: Record<string, string> = {
  normal: '#A8A878',    // Beige/Tan
  fire: '#F08030',      // Orange
  water: '#6890F0',     // Blue
  electric: '#F8D030',  // Yellow
  grass: '#78C850',     // Green
  ice: '#98D8D8',       // Cyan
  fighting: '#C03028',  // Red/Brown
  poison: '#A040A0',    // Purple
  ground: '#E0C068',    // Brown/Tan
  flying: '#A890F0',    // Light Purple
  psychic: '#F85888',   // Pink
  bug: '#A8B820',       // Yellow-Green
  rock: '#B8A038',      // Brown
  ghost: '#705898',     // Dark Purple
  dragon: '#7038F8',    // Indigo
  dark: '#705848',      // Dark Brown
  steel: '#B8B8D0',     // Silver
  fairy: '#EE99AC',     // Light Pink
};

/**
 * Gets the standard color for a Pokemon type
 * Returns a default gray if type is not found
 * 
 * @param type - Pokemon type name (lowercase)
 * @returns string - Hex color code
 * 
 * @example
 * getTypeColor('fire') // '#F08030'
 * getTypeColor('unknown') // '#777777'
 */
export const getTypeColor = (type: string): string => {
  return typeColors[type.toLowerCase()] || '#777777';
};

/**
 * Dark type colors
 * Darker variants used for text, borders, and badges on light backgrounds
 */
export const getTypeDarkColor = (type: string): string => {
  const colors: Record<string, string> = {
    normal: '#6D6D4E',
    fire: '#9C531F',
    water: '#445E9C',
    electric: '#A1871F',
    grass: '#4E8234',
    ice: '#638D8D',
    fighting: '#7D1F1A',
    poison: '#682A68',
    ground: '#927D44',
    flying: '#6D5E9C',
    psychic: '#A13959',
    bug: '#6D7815',
    rock: '#786824',
    ghost: '#493963',
    dragon: '#4924A1',
    dark: '#49392F',
    steel: '#787887',
    fairy: '#9B6470',
  };
  
  return colors[type.toLowerCase()] || '#555555';
};
