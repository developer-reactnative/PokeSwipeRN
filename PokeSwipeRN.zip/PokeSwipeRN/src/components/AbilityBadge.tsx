// AbilityBadge Component - Displays Pokemon ability as a styled badge

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { formatAbilityName } from '../services/pokeApi';
import { Theme } from '../context/ThemeContext';

interface AbilityBadgeProps {
  ability: string;
  theme: Theme;
}

const AbilityBadge: React.FC<AbilityBadgeProps> = ({ ability, theme }) => {
  return (
    <View style={[styles.badge, { backgroundColor: theme.accent }]}>
      <Text style={styles.text}>{formatAbilityName(ability)}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    borderRadius: 15,
    paddingHorizontal: 12,
    paddingVertical: 5,
    marginRight: 6,
    marginBottom: 4,
  },
  text: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 11,
  },
});

export default AbilityBadge;

