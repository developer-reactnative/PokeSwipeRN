// TypeBadge Component - Displays Pokemon type as a styled badge

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { getTypeColor } from '../utils/typeColors';

interface TypeBadgeProps {
  type: string;
  size?: 'small' | 'medium' | 'large';
}

const TypeBadge: React.FC<TypeBadgeProps> = ({ type, size = 'medium' }) => {
  const backgroundColor = getTypeColor(type);
  
  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { paddingHorizontal: 8, paddingVertical: 3, fontSize: 10 };
      case 'large':
        return { paddingHorizontal: 16, paddingVertical: 8, fontSize: 14 };
      default:
        return { paddingHorizontal: 12, paddingVertical: 5, fontSize: 12 };
    }
  };

  const sizeStyles = getSizeStyles();

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor,
          paddingHorizontal: sizeStyles.paddingHorizontal,
          paddingVertical: sizeStyles.paddingVertical,
        },
      ]}
    >
      <Text style={[styles.text, { fontSize: sizeStyles.fontSize }]}>
        {type.toUpperCase()}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    borderRadius: 20,
    marginRight: 6,
    marginBottom: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  text: {
    color: '#FFFFFF',
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
});

export default TypeBadge;

