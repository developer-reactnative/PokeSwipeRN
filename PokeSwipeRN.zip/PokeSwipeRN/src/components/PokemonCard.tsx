/**
 * PokemonCard Component
 * 
 * Displays a Pokemon with its image, name, types, abilities, and action buttons.
 * Used in the SwipeScreen for the main swipeable card.
 * 
 * FEATURES:
 * - Pokemon official artwork image
 * - Type-based color accent strip at top
 * - Pokemon ID badge (#001 format)
 * - Type badges (Fire, Water, etc.)
 * - Ability badges
 * - Like/Dislike buttons
 * - Live "LIKE"/"NOPE" overlay indicators during drag
 * - Themed heart icon
 * 
 * PROPS:
 * - pokemon: Pokemon data from API
 * - theme: Current theme (light/dark)
 * - onLike: Callback when like button pressed
 * - onDislike: Callback when dislike button pressed
 * - likeOpacity: Opacity for "LIKE" overlay (0-1)
 * - dislikeOpacity: Opacity for "NOPE" overlay (0-1)
 */

import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Dimensions,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { Pokemon } from '../types/pokemon';
import { formatPokemonName, getOfficialArtworkUrl } from '../services/pokeApi';
import { Theme } from '../context/ThemeContext';
import { getTypeColor, getTypeDarkColor } from '../utils/typeColors';
import TypeBadge from './TypeBadge';
import AbilityBadge from './AbilityBadge';

// Get device width for responsive sizing
const { width } = Dimensions.get('window');
// Card width - responsive but capped at 380px
const CARD_WIDTH = Math.min(width - 40, 380);

// Component prop types
interface PokemonCardProps {
  pokemon: Pokemon;           // Pokemon data from API
  theme: Theme;               // Current theme object
  isLoading?: boolean;        // Show loading state
  onLike: () => void;         // Like button callback
  onDislike: () => void;      // Dislike button callback
  likeOpacity?: number;       // "LIKE" overlay opacity (0-1)
  dislikeOpacity?: number;    // "NOPE" overlay opacity (0-1)
}

/**
 * PokemonCard Component
 * 
 * @param pokemon - Pokemon data object
 * @param theme - Current theme (light/dark)
 * @param isLoading - Whether to show loading state
 * @param onLike - Callback when like is pressed
 * @param onDislike - Callback when dislike is pressed
 * @param likeOpacity - Opacity for like overlay during drag
 * @param dislikeOpacity - Opacity for dislike overlay during drag
 */
const PokemonCard: React.FC<PokemonCardProps> = ({
  pokemon,
  theme,
  isLoading = false,
  onLike,
  onDislike,
  likeOpacity = 0,
  dislikeOpacity = 0,
}) => {
  // Get official artwork URL for this Pokemon
  const imageUrl = getOfficialArtworkUrl(pokemon.id);
  
  // Get primary type for color theming
  const primaryType = pokemon.types[0]?.type.name || 'normal';
  const typeColor = getTypeColor(primaryType);      // Lighter shade for backgrounds
  const typeDarkColor = getTypeDarkColor(primaryType);  // Darker shade for badges

  // Show loading spinner if loading
  if (isLoading) {
    return (
      <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.cardBorder }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.cardBorder }]}>
      {/* Type-based accent strip at top of card */}
      <View style={[styles.typeStrip, { backgroundColor: typeColor }]} />
      
      {/* "LIKE" Overlay - Appears when dragging right */}
      {likeOpacity > 0 && (
        <View style={[styles.overlay, styles.likeOverlay, { opacity: likeOpacity }]}>
          <Text style={styles.overlayText}>LIKE</Text>
        </View>
      )}
      
      {/* "NOPE" Overlay - Appears when dragging left */}
      {dislikeOpacity > 0 && (
        <View style={[styles.overlay, styles.dislikeOverlay, { opacity: dislikeOpacity }]}>
          <Text style={styles.overlayText}>NOPE</Text>
        </View>
      )}

      {/* Heart Icon - Colored based on Pokemon type */}
      <View style={[styles.heartContainer, { backgroundColor: `${typeColor}30` }]}>
        <Text style={[styles.heartIcon, { color: typeColor }]}>♥</Text>
      </View>

      {/* Pokemon ID Badge - Shows #001, #025, etc. */}
      <View style={[styles.idBadge, { backgroundColor: typeDarkColor }]}>
        <Text style={styles.idText}>#{pokemon.id.toString().padStart(3, '0')}</Text>
      </View>

      {/* Pokemon Image - Official artwork from PokeAPI */}
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: imageUrl }}
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      {/* Pokemon Name - Formatted and uppercase */}
      <Text style={[styles.name, { color: theme.text }]}>
        {formatPokemonName(pokemon.name)}
      </Text>

      {/* Types and Abilities Section */}
      <View style={styles.badgesContainer}>
        {/* Type Badges - Fire, Water, Grass, etc. */}
        <View style={styles.badgeRow}>
          {pokemon.types.map((typeInfo, index) => (
            <TypeBadge key={index} type={typeInfo.type.name} />
          ))}
        </View>

        {/* Ability Badges - Shows up to 2 abilities */}
        <View style={styles.badgeRow}>
          {pokemon.abilities.slice(0, 2).map((abilityInfo, index) => (
            <AbilityBadge
              key={index}
              ability={abilityInfo.ability.name}
              theme={theme}
            />
          ))}
        </View>
      </View>

      {/* Action Buttons - Like and Dislike */}
      <View style={styles.buttonContainer}>
        {/* Dislike Button - Red with X icon */}
        <TouchableOpacity
          style={[styles.button, styles.dislikeButton]}
          onPress={onDislike}
          activeOpacity={0.8}
        >
          <Text style={styles.buttonText}>✕ Dislike</Text>
        </TouchableOpacity>

        {/* Like Button - Green with heart icon */}
        <TouchableOpacity
          style={[styles.button, styles.likeButton]}
          onPress={onLike}
          activeOpacity={0.8}
        >
          <Text style={styles.buttonText}>♥ Like</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

/**
 * Styles for PokemonCard
 */
const styles = StyleSheet.create({
  // Main card container
  card: {
    width: CARD_WIDTH,
    borderRadius: 24,
    padding: 20,
    paddingTop: 8,
    alignItems: 'center',
    // Shadow for iOS
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    // Shadow for Android
    elevation: 8,
    borderWidth: 1,
    overflow: 'hidden',
  },
  // Colored strip at top based on Pokemon type
  typeStrip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 6,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  // Base overlay style for LIKE/NOPE indicators
  overlay: {
    position: 'absolute',
    top: 50,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 3,
    zIndex: 10,
  },
  // "LIKE" overlay - positioned right, green, rotated
  likeOverlay: {
    right: 20,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    borderColor: '#4CAF50',
    transform: [{ rotate: '15deg' }],
  },
  // "NOPE" overlay - positioned left, red, rotated opposite
  dislikeOverlay: {
    left: 20,
    backgroundColor: 'rgba(255, 107, 107, 0.1)',
    borderColor: '#FF6B6B',
    transform: [{ rotate: '-15deg' }],
  },
  // Overlay text style
  overlayText: {
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 2,
  },
  // Heart icon container
  heartContainer: {
    position: 'absolute',
    top: 16,
    right: 18,
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heartIcon: {
    fontSize: 16,
  },
  // Pokemon ID badge container
  idBadge: {
    position: 'absolute',
    top: 16,
    left: 18,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  idText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  // Pokemon image container
  imageContainer: {
    width: 180,
    height: 180,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  // Pokemon name text
  name: {
    fontSize: 28,
    fontWeight: '800',
    marginTop: 8,
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 2,
    textAlign: 'center',
  },
  // Container for type and ability badges
  badgesContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  // Row of badges (types or abilities)
  badgeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 6,
  },
  // Button container
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 6,
  },
  // Base button style
  button: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 25,
    alignItems: 'center',
    marginHorizontal: 6,
    // Shadow
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  // Dislike button - red
  dislikeButton: {
    backgroundColor: '#FF6B6B',
  },
  // Like button - green
  likeButton: {
    backgroundColor: '#4CAF50',
  },
  // Button text
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});

export default PokemonCard;
