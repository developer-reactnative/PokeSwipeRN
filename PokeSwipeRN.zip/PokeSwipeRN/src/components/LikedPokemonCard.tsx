// LikedPokemonCard Component - Displays a liked Pokemon in the collection grid

import React from 'react';
import { View, Text, Image, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { LikedPokemon } from '../types/pokemon';
import { Theme } from '../context/ThemeContext';
import { formatPokemonName } from '../services/pokeApi';
import { getTypeColor } from '../utils/typeColors';

const { width } = Dimensions.get('window');
const CARD_SIZE = (width - 60) / 2;

interface LikedPokemonCardProps {
  pokemon: LikedPokemon;
  theme: Theme;
  onPress?: () => void;
}

const LikedPokemonCard: React.FC<LikedPokemonCardProps> = ({ pokemon, theme, onPress }) => {
  const primaryType = pokemon.types[0] || 'normal';
  const typeColor = getTypeColor(primaryType);

  return (
    <TouchableOpacity 
      style={[styles.card, { backgroundColor: theme.card, borderColor: theme.cardBorder }]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* Type-based accent strip */}
      <View style={[styles.typeStrip, { backgroundColor: typeColor }]} />
      
      {/* Pokemon ID */}
      <View style={[styles.idBadge, { backgroundColor: typeColor }]}>
        <Text style={styles.idText}>#{pokemon.id.toString().padStart(3, '0')}</Text>
      </View>

      <View style={styles.imageContainer}>
        <Image
          source={{ uri: pokemon.imageUrl }}
          style={styles.image}
          resizeMode="contain"
        />
      </View>
      
      <Text style={[styles.name, { color: theme.text }]}>
        {formatPokemonName(pokemon.name)}
      </Text>

      {/* Type badges */}
      <View style={styles.typesContainer}>
        {pokemon.types.slice(0, 2).map((type, index) => (
          <View key={index} style={[styles.typeBadge, { backgroundColor: getTypeColor(type) }]}>
            <Text style={styles.typeText}>{type.toUpperCase()}</Text>
          </View>
        ))}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    width: CARD_SIZE,
    borderRadius: 16,
    padding: 12,
    paddingTop: 8,
    margin: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    overflow: 'hidden',
  },
  typeStrip: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 4,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  idBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  idText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '700',
  },
  imageContainer: {
    width: CARD_SIZE - 40,
    height: CARD_SIZE - 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  name: {
    fontSize: 13,
    fontWeight: '700',
    marginTop: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    textAlign: 'center',
  },
  typesContainer: {
    flexDirection: 'row',
    marginTop: 6,
    gap: 4,
  },
  typeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  typeText: {
    color: '#FFFFFF',
    fontSize: 8,
    fontWeight: '700',
  },
});

export default LikedPokemonCard;
