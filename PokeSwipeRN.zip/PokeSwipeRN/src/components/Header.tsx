// Header Component - App header with PokeAPI logo and navigation

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Theme } from '../context/ThemeContext';

interface HeaderProps {
  theme: Theme;
  showBackButton?: boolean;
  onBackPress?: () => void;
  showDarkModeToggle?: boolean;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  title?: string;
}

const Header: React.FC<HeaderProps> = ({
  theme,
  showBackButton = false,
  onBackPress,
  showDarkModeToggle = false,
  isDarkMode = false,
  onToggleDarkMode,
  title,
}) => {
  return (
    <View style={[styles.header, { backgroundColor: theme.headerBackground }]}>
      {/* Left Section - Back Button */}
      <View style={styles.leftSection}>
        {showBackButton && (
          <TouchableOpacity onPress={onBackPress} style={styles.backButton}>
            <Text style={[styles.backIcon, { color: theme.text }]}>‹</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Center - Logo */}
      <View style={styles.centerSection}>
        <Text style={styles.logoText}>
          <Text style={styles.logoBlue}>Poké</Text>
          <Text style={styles.logoYellow}>API</Text>
        </Text>
        {title && (
          <Text style={[styles.title, { color: theme.text }]}>{title}</Text>
        )}
      </View>

      {/* Right Section - Dark Mode Toggle */}
      <View style={styles.rightSection}>
        {showDarkModeToggle && (
          <TouchableOpacity onPress={onToggleDarkMode} style={styles.toggleButton}>
            <Text style={styles.toggleIcon}>{isDarkMode ? '☀️' : '🌙'}</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
  },
  leftSection: {
    width: 50,
    alignItems: 'flex-start',
  },
  centerSection: {
    flex: 1,
    alignItems: 'center',
  },
  rightSection: {
    width: 50,
    alignItems: 'flex-end',
  },
  logoText: {
    fontSize: 28,
    fontWeight: '800',
    fontStyle: 'italic',
  },
  logoBlue: {
    color: '#3B5BA7',
  },
  logoYellow: {
    color: '#FFCB05',
  },
  title: {
    fontSize: 14,
    marginTop: 2,
    fontWeight: '500',
  },
  backButton: {
    padding: 4,
  },
  backIcon: {
    fontSize: 36,
    fontWeight: '300',
  },
  toggleButton: {
    padding: 8,
  },
  toggleIcon: {
    fontSize: 24,
  },
});

export default Header;

