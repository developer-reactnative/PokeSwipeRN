/**
 * PokeSwipe - A Tinder-style Pokemon Swiping Application
 * 
 * This is the main entry point of the application.
 * 
 * FEATURES:
 * - Swipe through random Pokemon fetched from PokeAPI
 * - Like or Dislike Pokemon with Tinder-style animations
 * - Gesture-based swiping (drag cards left/right)
 * - View collection of liked Pokemon
 * - Dark mode support with persistent storage
 * - Type-based color styling for Pokemon cards
 * 
 * TECH STACK:
 * - React Native 0.83.1
 * - React Navigation for screen navigation
 * - AsyncStorage for data persistence
 * - PokeAPI (https://pokeapi.co/) for Pokemon data
 * 
 * @author PokeSwipe Team
 * @version 1.0.0
 */

import React from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PokemonProvider } from './src/context/PokemonContext';
import AppNavigator from './src/navigation/AppNavigator';

/**
 * App Component
 * 
 * The root component that wraps the entire application with:
 * - SafeAreaProvider: Handles safe area insets for notched devices
 * - PokemonProvider: Global state management for liked Pokemon and settings
 * - AppNavigator: Navigation stack for all screens
 */
const App: React.FC = () => {
  return (
    // SafeAreaProvider ensures content doesn't overlap with device notches/status bars
    <SafeAreaProvider>
      {/* PokemonProvider provides global state for liked Pokemon, dark mode, etc. */}
      <PokemonProvider>
        {/* AppNavigator contains all screen routes and navigation logic */}
        <AppNavigator />
      </PokemonProvider>
    </SafeAreaProvider>
  );
};

export default App;
